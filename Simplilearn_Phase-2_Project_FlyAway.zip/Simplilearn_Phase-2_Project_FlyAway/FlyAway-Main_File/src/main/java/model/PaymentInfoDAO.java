package model;

public interface PaymentInfoDAO 
{
  boolean addPaymentinfo(PaymentInfo payInfo);
  
}